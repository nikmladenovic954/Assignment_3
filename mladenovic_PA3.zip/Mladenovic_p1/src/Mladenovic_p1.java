import java.util.Scanner;
import java.security.SecureRandom;

    //Nikolas Mladenovic
    //Part 1 assignment 3

    class Main {

        private static int random1, random2, solution;
        private static int correctAnswers = 0;

         private static int operation = 0;
         private static int level;

         public static void main(String[] args) {

        Scanner scnr = new Scanner(System.in);
        // input dificulty setting user wants to challange

        int i = 0;

        while (true) {

                while (level > 4 || level < 1) {

                System.out.print("enter problem difficulty (1 through 4) : ");
                    level = scnr.nextInt();

                  }
                //enter operation user wants to operate

                        while (operation > 5 || operation < 1) {
                        System.out.print("enter problem type: \n 1 : addition  \n 2 : multiplication \n 3 : subtraction \n 4 : division \n 5 : randomized problems \n ");

                        operation = scnr.nextInt();

                  }

            questionPrinter();
        }

    }

    private static void askQuestion() {
        SecureRandom rand = new SecureRandom();
//question types and difficulty

        switch (level) {

            case 1:
                random1 = rand.nextInt(10);
                random2 = rand.nextInt(10);

                while (random2 == 0) {

                    random2 = rand.nextInt(10);

                }

                break;

                 case 2:
                random1 = rand.nextInt(100);
                random2 = rand.nextInt(100);

                while (random2 == 0) {

                    random2 = rand.nextInt(100);

                }

                break;

                case 3:
                random1 = rand.nextInt(1000);
                random2 = rand.nextInt(1000);

                while (random2 == 0) {

                    random2 = rand.nextInt(1000);
                }

                break;

                  case 4:

                random1 = rand.nextInt(10000);
                random2 = rand.nextInt(10000);

                while (random2 == 0) {

                    random2 = rand.nextInt(10000);

                }

                break;
        }
//arithmetic operations
             switch (operation) {
                case 1:
                solution = random1 + random2;

                System.out.printf("How much is %d + %d? \n", random1 , random2);

                break;

             case 2:
                solution = random1 * random2;

                System.out.printf("How much is %d * %d? \n", random1 , random2);

                break;

             case 3:
                solution = random1 - random2;

                System.out.printf("How much is %d - %d? \n", random1 , random2);

                break;
                 case 4:
                solution = random1 / random2;

                System.out.printf("How much is %d / %d? \n", random1 , random2);
                break;

                case 5:

                int tem = rand.nextInt(4);

                switch(tem) {

                    case 0:

                        solution = random1 + random2;

                        System.out.printf("How much is %d + %d? \n", random1 , random2);
                        break;

                    case 1:

                        solution = random1 * random2;

                        System.out.printf("How much is %d * %d? \n", random1 , random2);
                        break;

                    case 2:

                        solution = random1 - random2;

                        System.out.printf("How much is %d - %d? \n", random1, random2);
                        break;

                    case 3:

                        solution = random1 / random2;

                        System.out.printf("How much is %d / %d? \n", random1, random2);
                        break;
                }
                break;
        }

        checkSolution (getSolution() , solution);

      }
    private static void percentChecker() {

        double percentage = ((double) correctAnswers / 10.00) * 100.00;
        System.out.println("Percent of answers correct: %" + percentage);

            if (percentage >= 75.00) {

            System.out.println("Congratulations you passed !");
            System.out.println("continue with a new student: ");

                level = 0;
                operation = 0;

              }
              else {

                     System.out.println("ask your teacher for help and practice....");
                     System.out.println("continue with a new student:");

                        level = 0;
                        operation = 0;
             }
            }
             private static void questionPrinter() {

             for (int i = 0; i < 10; i++) {


             askQuestion();

             }

        percentChecker();

    }

         private static void checkSolution(int userAnswer, int solution) {

        if (userAnswer == solution) {
                     correctAnswer();

            }

        else {
            incorrectAnswer();

         }

      }

    private static int getSolution() {

        Scanner scnr = new Scanner(System.in);

        return scnr.nextInt();
    }

         private static void correctAnswer() {

        SecureRandom random = new SecureRandom();
        correctAnswers++;

        int x = (random.nextInt(5) + 1);

        switch (x) {

                 case 1:
                System.out.println("Good ! ");
                break;

                 case 2:
                System.out.println("Keep going ! ");
                break;

                 case 3:
                System.out.println("Good job ! ");
                break;

                case 4:
                System.out.println("Nice job ! ");
                break;

                default:
                System.out.println("Correct ! ");
                break;
        }

             }

         private static void incorrectAnswer() {
         SecureRandom rando = new SecureRandom();

        int y = (rando.nextInt(5) + 1);

                 switch (y) {

                        case 1:
                            System.out.println("Try again ! ");
                            break;

                         case 2:
                             System.out.println("Wrong ! ");
                            break;

                         case 3:
                             System.out.println("Whoops, not correct ! ");
                             break;

                         case 4:
                              System.out.println("Wrong again ! ");
                             break;

                             default:
                             System.out.println("Incorrect ! ");
                             break;


             }

         }
       }
